import React from 'react'
import "./Navbar.css"
const Navbar = () => {
    return (
      <>
        <div className="bg-[#254336] mb-1">
          <div className="container max-w-[1200px] mx-auto">
            <div className="flex items-center h-[100px] justify-around relative">
              <img
                className=" absolute left-[20%]"
                src="./Images/Art1.png"
                alt=""
              />
              <img
                className=" absolute right-[12%] top-0 rotate-180"
                src="./Images/Art1.png"
                alt=""
              />
              <img src="./Images/Logo.png" alt="Logo" />
              <div className=" font-literal w-[249px] font-normal text-center text-[14px] leading-[22px]">
                <h4 className="text-yellow-500">
                  3rd SAARC SPORTSMED CON. BANGLADESH
                </h4>
                <h4 className=" text-white text-[12px] font-semibold leading-[18px]">
                  Hosted by BD Arthroscopy & Arthroplasty Academy
                </h4>
              </div>
              <div className=" font-literal w-[249px] font-normal text-center text-[16px] leading-[22px]">
                <h4 className="text-yellow-500">Conference Theme</h4>
                <h4 className=" text-white text-[12px] font-semibold leading-[18px]">
                  “Enhancing Skills, Optimising Care”
                </h4>
              </div>
              <button className="bg-[#254336] text-white border py-1 px-2 rounded-lg">
                Contact Us
              </button>
            </div>
          </div>
        </div>
        <div className="bg-[#254336]">
          <div className="container max-w-[1200px] mx-auto">
            <div className="bg-[#254336]">
              <ul className=" flex justify-around">
                <li className=" navlink "><a href="">HOME</a></li>
                <li className=" navlink"><a href="">MESSAGE</a></li>
                <li className=" navlink"><a href="">COMMITTEE</a></li>
                <li className=" navlink"><a href="">FACULTY</a></li>
                <li className=" navlink"><a href="">REGISTRATION</a></li>
                <li className=" navlink"><a href="">ABSTRACT</a></li>
                <li className=" navlink"><a href="">ABOUT BANGLADESH</a></li>
              </ul>
            </div>
          </div>
        </div>
      </>
    );
  };
  

export default Navbar